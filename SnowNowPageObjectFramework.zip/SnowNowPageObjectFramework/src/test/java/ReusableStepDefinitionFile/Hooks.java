package ReusableStepDefinitionFile;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.mail.EmailException;
import org.apache.poi.util.SystemOutLogger;

import com.cucumber.listener.Reporter;
import com.service.pageobjectmanager.FileReaderManager;
import com.snow.textcontext.TextContext;


import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks {
	 private List <String> fileList;
	    private static final String OUTPUT_ZIP_FILE = System.getProperty("user.dir")+"//Folder.zip";
	    private static final String SOURCE_FOLDER = System.getProperty("user.dir")+"\\target\\CucumberReport"; // SourceFolder path
	public TextContext textContext;
	public Hooks(TextContext context) {
		textContext = context;
	}
	@Before
	public void BeforeSteps() {
		
		Reporter.loadXMLConfig(new File(FileReaderManager.getInstance().getConfigReader().getReportConfigPath()));
		 Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
	    Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
	    Reporter.setSystemInfo("Machine", "Windows 10" + "64 Bit");
	    Reporter.setSystemInfo("Selenium", "3.7.0");
	    Reporter.setSystemInfo("Maven", "3.5.2");
	    Reporter.setSystemInfo("Java Version", "1.8.0_151");
		/*What all you can perform here
			Starting a webdriver
			Setting up DB connections
			Setting up test data
			Setting up browser cookies
			Navigating to certain page
			or anything before the test
		*/
	}
	
	@After 
	public void AfterSteps() throws EmailException {
		System.out.println("QQQQQQQQ");
textContext.getPageObjectManager().getWebDriverManager().quitDriver();
textContext.getPageObjectManager().getWebDriverManager().quitDriver2();

//		textContext.getPageObjectManagerIETL().getWebDriverManager().quitDriver();
//		customefunction.sleep(10000);
//		ZipUtils sp=new ZipUtils();
//	
//		sp.zipfile();


/*String xpath=System.getProperty("user.dir")+"\\target\\CucumberReport\\ExtentReport.html";


Scanner fileScanner = null;
try {
	fileScanner = new Scanner(new File(System.getProperty("user.dir")+"\\target\\CucumberReport\\ExtentReport.html"));
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

Pattern pattern1 = Pattern.compile("(>)(\\d+)(<\\/span> scenario\\(s\\) passed)");
Pattern pattern2 = Pattern.compile("(>)(\\d+)(<\\/span> scenario\\(s\\) failed)");
Matcher matcher1 = null;
Matcher matcher2 = null;

String strFailCount = "0";
String strPassCount = "0";
while (fileScanner.hasNextLine()) {
	String line = fileScanner.nextLine();
	matcher1 = pattern1.matcher(line);
	matcher2 = pattern2.matcher(line);
	if (matcher1.find()) {
		strPassCount = matcher1.group(2);

	}

	if (matcher2.find()) {
		strFailCount = matcher2.group(2);

	}
	
	System.out.println("Pass count"+strPassCount);
	System.out.println("Fail count"+strFailCount);
	
}	
if(Integer.parseInt(strFailCount)!=0)
{
EmailSent.sendEmail(xpath, strFailCount,strPassCount );
}
else
{
	EmailSent.sendEmail2(xpath, strFailCount,strPassCount);
}*/
}
	
	
		
		
		
	        
}
	

	
