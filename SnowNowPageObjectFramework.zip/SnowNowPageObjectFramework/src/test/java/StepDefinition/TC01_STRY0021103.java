package StepDefinition;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.service.pageobjectmanager.PageObjectManager;
import com.service.pageobjectmanager.PageObjectManagerIETL;
import com.snow.base.TestBase;
import com.snow.customfunction.customefunction;
import com.snow.enums.Context;
import com.snow.finalVariable.FinalVar;
import com.snow.log.Log;
import com.snow.pages.ConfirmationPage;
import com.snow.pages.HPPrinterItemObj;
import com.snow.pages.IncidentPage_MLF_Object;
import com.snow.pages.RPSSDTechnicalSupportModeObj;
import com.snow.textcontext.TextContext;
import com.snow.util.DataHelper;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TC01_STRY0021103 {
	public static TextContext textContext;
	
	
	
	public static PageObjectManager PageObjectManager;

	public static PageObjectManagerIETL PageObjectManagerIETL;
	public static IncidentPage_MLF_Object IncidentPage_MLF;
	public static String SIRNum;
	List<HashMap<String, String>> dataSet;
	public static RPSSDTechnicalSupportModeObj RPSSDTechnicalSupportMode;
	public static String PartailText;
	public static String FullText;
	public static String xpath;;
	public static String stringVal;
	public static HPPrinterItemObj HPPrinterItem;
	
	public TC01_STRY0021103(TextContext con)
	{

		textContext=	con;
		

		
	}
	

	@Then("^Fill all the mandatory fields$")
	public void fill_all_the_mandatory_fields() throws Throwable {
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'select2-drop')]//div//following::ul//child::li//..)[1]//preceding-sibling::div//input";
		customefunction.sendKeys(xpath, "Portia Deb", TestBase.driver);
		customefunction.sleep(4000);
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="//*[@id=\"sp_formfield_name_des\"]";
		customefunction.sendKeys(xpath, "1099 Pro, Inc.", TestBase.driver);
		xpath="//*[@id=\"sp_formfield_u_vendor\"]";
		customefunction.sendKeys(xpath, "Manulife", TestBase.driver);
		
		xpath="//*[@id=\"sp_formfield_es_cost\"]";
		customefunction.sendKeys(xpath, "1234", TestBase.driver);
		xpath="//*[@id=\"sp_formfield_deskside_team\"]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'select2-drop')]//div//following::ul//child::li//..)[1]//preceding-sibling::div//input";
		customefunction.sendKeys(xpath, "7815", TestBase.driver);
		customefunction.sleep(3000);
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[4]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		customefunction.sleep(3000);
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		
	}
	@Then("^navigate to the back page$")
	public void navigate_to_the_back_page() throws Throwable {
//		TestBase.driver2.navigate().back();   
//		customefunction.sleep(3000);
		TestBase.driver2.switchTo().defaultContent();
		customefunction.cusFunSerrachINCorREQ(TestBase.driver2, RPSSDTechnicalSupportModeObj.reNum);
		customefunction.sleep(3000);
	}

	@Then("^scroll to the bottom$")
	public void scroll_to_the_bottom() throws Throwable {
		customefunction.SwitchToFrmaeByNameOrID(TestBase.driver2, "gsft_main");
		xpath="//*[@id='page_timing_div,]/button";
		customefunction.cFunScrollToElement(xpath, TestBase.driver2);
	}
	@Then("^click on the purchase order tab$")
	public void click_on_the_purchase_order_tab() throws Throwable {
		
		xpath="//*[@id='tabs2_list']/span[4]/span/span[2]";
	
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver2).click();
	}

	@Then("^click on the purchase order link$")
	public void click_on_the_purchase_order_link() throws Throwable {
		
		xpath="//*[@id='page_timing_div,]/button";
		customefunction.cFunScrollToElement(xpath, TestBase.driver2);
		xpath="(//*[contains(@id,'row_sc_request.')])[2]//td[3]//a";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver2).click();
		customefunction.sleep(3000);
		xpath="//*[@id=\"proc_po.description\"]";
		customefunction.cFunScrollToElement(xpath, TestBase.driver2);
	}
	
	@SuppressWarnings("static-access")
	@Then("^verify the total cost currency doller is \"([^\"]*)\"$")
	public void verify_the_total_cost_currency_doller_is(String arg1) throws Throwable {
		
		xpath="//select[@id='proc_po.total_cost.currency']//option[3]";
		String str=TestBase.driver2.findElement(By.xpath(xpath)).getText();
		System.out.println("strobj : "+str);
	textContext.getScenarioContext().setContext(Context.TotalCoast_Currency, str);
		String  obj=(String)textContext.getScenarioContext().getContext(Context.TotalCoast_Currency);
		System.out.println("Getobj : "+obj);
		ConfirmationPage confirmationPage = textContext.getPageObjectManagerIETL().getConfirmationPage();
		System.out.println("confirmationPage : "+confirmationPage);
		List<String> ls=confirmationPage.getTotaCostCurrency();
		System.out.println("List : "+ls);
	//Assert.assertTrue(confirmationPage.getTotaCostCurrency().stream().filter(x -> x.contains(arg1)).findFirst().get().length()>0);
		Reporter.addStepLog("Currency : "+str);
	}

	
	@Then("^filled the manadatory field of the form add access$")
	public void filled_the_manadatory_field_of_the_form() throws Throwable {
//		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		/*xpath="(//*[contains(@id,'select2-drop')]//div//following::ul//child::li//..)[1]//preceding-sibling::div//input";
		customefunction.sendKeys(xpath, "vietnam", TestBase.driver);
		customefunction.sleep(3000);*/
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[2]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[2]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[2]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
	
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[4]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[2]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="#submit";
		customefunction.cFunScrollToElementCss(xpath, TestBase.driver);
		xpath="//*[@id=\"submit\"]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(text(),'ACL Add')]//following::div//span)[3]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[3]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[2]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[4]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'select2-drop')]//div//following::ul//child::li//..)[1]//preceding-sibling::div//input";
		customefunction.sendKeys(xpath, "MOD", TestBase.driver);
		customefunction.sleep(3000);
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[7]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();

		xpath="(//*[contains(@id,'select2-drop')]//div//following::ul//child::li//..)[1]//preceding-sibling::div//input";
		customefunction.sendKeys(xpath, "acl_bu_mps_all - MOD - SADB0071013", TestBase.driver);
		customefunction.sleep(3000);
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="#submit";
		customefunction.cFunScrollToElementCss(xpath, TestBase.driver);
		xpath="//*[@id=\"submit\"]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="//*[text()='Order Now']";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		
	}
	@Then("^verify RITM state moves to \"([^\"]*)\"$")
	public void verify_RITM_state_moves_to(String arg1) throws Throwable {
		WebElement ele = null;
		customefunction.FluentWaitRITMState(ele, 200, TestBase.driver2, arg1)  ;
	}
	@Then("^filled the manadatory field of the form remove access$")
	public void filled_the_manadatory_field_of_the_form_remove_access() throws Throwable {
		
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		/*xpath="(//*[contains(@id,'select2-drop')]//div//following::ul//child::li//..)[1]//preceding-sibling::div//input";
		customefunction.sendKeys(xpath, "vietnam", TestBase.driver);
		customefunction.sleep(3000);*/
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[2]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[2]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[2]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
	
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[4]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[2]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="#submit";
		customefunction.cFunScrollToElementCss(xpath, TestBase.driver);
		xpath="//*[@id=\"submit\"]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(text(),'ACL Add / Remove Re')])[2]";
		//customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[3]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[3]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[5]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'select2-drop')]//div//following::ul//child::li//..)[1]//preceding-sibling::div//input";
		customefunction.sendKeys(xpath, "MOD", TestBase.driver);
		customefunction.sleep(3000);
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="(//*[contains(@id,'s2id_sp_formfield_')]//a)[7]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();

		xpath="(//*[contains(@id,'select2-drop')]//div//following::ul//child::li//..)[1]//preceding-sibling::div//input";
		customefunction.sendKeys(xpath, "acl_bu_mps_all - MOD - SADB0071013", TestBase.driver);
		customefunction.sleep(3000);
		xpath="//*[contains(@id,'select2-drop')]//div//following::ul//child::li[1]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="#submit";
		customefunction.cFunScrollToElementCss(xpath, TestBase.driver);
		xpath="//*[@id=\"submit\"]";
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();
		xpath="//*[text()='Order Now']";
		/*customefunction.cFunScrollToElement(xpath, TestBase.driver);*/
		
		customefunction.waitVisibilityOfElementLocated(xpath, 15, TestBase.driver).click();   
	}
}
