package com.servicenow.practice;

import org.apache.poi.util.SystemOutLogger;

public class ImmutableCl {
public static void  main(String arg[])
{
//	Employee e=new Employee("AA");
//	
//	System.out.println(e.getPancardNumber());
//	String s="sdffsdfsdf";
//	s=" ";
	
//	String str="My name is manish",rev="";
//	char ch[]=str.toCharArray();
//	for(int i=str.length()-1;i>=0;i--)
//	{
//		rev=rev+str.charAt(i);
//	}
//	System.out.println(rev);
	
	Employee fl=new Employee();
	
System.out.println(fl.getPancardNumber());
}
}
