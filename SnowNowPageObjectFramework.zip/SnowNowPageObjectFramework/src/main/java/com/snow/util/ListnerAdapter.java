package com.snow.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.mail.EmailException;
import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.snow.base.TestBase;

public class ListnerAdapter implements ITestListener {
	public static ExtentHtmlReporter HtmlReporter;
	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String strReportPath;
	public static String strJSPath;
	public static String timeStamp;
	private LinkedList<String> lines;

	@Override
	public void onTestStart(ITestResult result) {

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailure(ITestResult result) {
		/*
		 * System.out.println("Test failed :"+Thread.currentThread().getId() + "diver:"
		 * + TestBase.driver2); if (result.getStatus() == ITestResult.FAILURE) {
		 * TestBase.logger.log(Status.FAIL, result.getThrowable()); SimpleDateFormat
		 * dateFormat = new SimpleDateFormat("yyy_mm_dd_hh_mm_ss"); String timeStamp =
		 * dateFormat.format(new Date()); TakesScreenshot tk = ((TakesScreenshot)
		 * TestBase.driver2); File src = tk.getScreenshotAs(OutputType.FILE);
		 * 
		 * StringTokenizer st1 = new StringTokenizer(System.getProperty("user.dir"),
		 * "\\"); LinkedList<String> ls = new LinkedList<String>();
		 * 
		 * while (st1.hasMoreTokens()) { ls.add(st1.nextToken()); }
		 * 
		 * StringBuilder ScreenshotDir = new StringBuilder();
		 * 
		 * for (int i = 0; i < ls.size() - 1; i++) { ScreenshotDir.append("\\" +
		 * ls.get(i));
		 * 
		 * }
		 * 
		 * File dst = new
		 * File("\\" + ScreenshotDir + "\\" + "TestCase" + "\\screenshots" +
		 * result.getMethod().getMethodName() + timeStamp + ".png"); try {
		 * FileUtils.copyFile(src, dst);
		 * TestBase.logger.addScreenCaptureFromPath(dst.toString()); } catch
		 * (IOException e) {
		 * 
		 * e.printStackTrace(); } }
		 */

	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onStart(ITestContext context) {

		
		

	}

	@Override
	public void onFinish(ITestContext context) {
		String xpath=System.getProperty("user.dir")+"\\target\\CucumberReport\\ExtentReport.html";


		Scanner fileScanner = null;
		try {
			fileScanner = new Scanner(new File(System.getProperty("user.dir")+"\\target\\CucumberReport\\ExtentReport.html"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Pattern pattern1 = Pattern.compile("(>)(\\d+)(<\\/span> scenario\\(s\\) passed)");
		Pattern pattern2 = Pattern.compile("(>)(\\d+)(<\\/span> scenario\\(s\\) failed)");
		Matcher matcher1 = null;
		Matcher matcher2 = null;

		String strFailCount = "0";
		String strPassCount = "0";
		while (fileScanner.hasNextLine()) {
			String line = fileScanner.nextLine();
			matcher1 = pattern1.matcher(line);
			matcher2 = pattern2.matcher(line);
			if (matcher1.find()) {
				strPassCount = matcher1.group(2);

			}

			if (matcher2.find()) {
				strFailCount = matcher2.group(2);

			}
			
			
			
		}
		System.out.println("Pass count"+strPassCount);
		System.out.println("Fail count"+strFailCount);
		if(Integer.parseInt(strFailCount)!=0)
		{
		try {
			EmailSent.sendEmail(xpath, strFailCount,strPassCount );
		} catch (EmailException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		else
		{
			try {
				EmailSent.sendEmail2(xpath, strFailCount,strPassCount);
			} catch (EmailException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
			
	}


