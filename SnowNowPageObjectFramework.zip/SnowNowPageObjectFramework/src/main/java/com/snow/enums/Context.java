package com.snow.enums;

public enum Context {
	
	TotalCoast_Currency;
	
}
