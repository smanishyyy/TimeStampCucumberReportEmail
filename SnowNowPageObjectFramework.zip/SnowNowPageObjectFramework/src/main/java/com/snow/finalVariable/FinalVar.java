package com.snow.finalVariable;

public class FinalVar {
	public static final String ExcelPathRead="/TestData/Testdata.xlsx";
	public static final String ExcelPathWrite="\\TestData/Testdata.xlsx";
}

